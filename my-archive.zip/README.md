# Text-to-HTML Browser Addon

This extension adds bold to interviews, articles and fact sheets.

NB: use `git archive -o my-archive.zip HEAD` to create the extension zip file without the “.git” folder.

Version 0.2 was published on the [Chrome Web Store](https://chrome.google.com/webstore/detail/convertisseur-textehtml/pggkolecpaldniejpimefojpacbhjbmb).

I’m updating the code I wrote for http://br.tcch.ch — «Convertisseur texte ⇢ HTML pour journalistes et blogueurs».
