# Text-to-HTML Browser Addon

This extension adds bold to interviews, articles and fact sheets.

NB: use `git archive -o my-archive.zip HEAD` to create the extension zip file without the “.git” folder.

Available on [Firefox Add-ons](https://addons.mozilla.org/en-US/firefox/addon/convertisseur-texte-html/) and the [Chrome Web Store](https://chrome.google.com/webstore/detail/convertisseur-textehtml/pggkolecpaldniejpimefojpacbhjbmb).

I’m updating the code I wrote for http://br.tcch.ch — «Convertisseur texte ⇢ HTML pour journalistes et blogueurs».
